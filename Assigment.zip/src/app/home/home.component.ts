import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ExcelsheetService } from '../service/excelsheet.service';


export interface TableElement {
  age: string
  country: string
  dob: string
  firstname: string
  gender: string
  no: string
  lastname: string
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements AfterViewInit {

  dataSource = new MatTableDataSource<TableElement>([]);
  displayedColumns: string[] = ['no', 'firstname', 'lastname', 'gender', 'country', 'age', 'dob'];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private sheetService: ExcelsheetService) { }

  ngAfterViewInit(): void {
    this.sheetService.getSheet().subscribe(res => {
      this.dataSource.data = res;
      console.log(this.dataSource.data);
    });

    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  setupFilter(column: string) {
    this.dataSource.filterPredicate = (d: TableElement, filter: string) => {
      const textToSearch = d[column] && d[column].toLowerCase() || '';
      return textToSearch.indexOf(filter) !== -1;
    };
  }

  applyFilter(filterValue: string) {
    console.log(filterValue);
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}
